export const navItems = [
  { label: 'Home', path: '/', icon: 'home' },
  { label: 'About', path: '/about', icon: 'person' },
  { label: 'Skills', path: '/skills', icon: 'terminal' },
  { label: 'Projects', path: '/projects', icon: 'code' },
  { label: 'Education', path: '/education', icon: 'school' },
  { label: 'Contact', path: '/contact', icon: 'mail' },
];

export const projects = [
  {
    category: 'Architecture',
    title: 'NexusFlow Logistics',
    icon: 'architecture',
    description:
      'Event-driven microservices architecture for real-time supply chain tracking with sub-200ms latency across multi-region AWS clusters.',
    stack: ['Kubernetes', 'Go', 'Kafka'],
    status: 'Completed',
    statusTone: 'completed',
  },
  {
    category: 'AI / ML',
    title: 'DocuMind AI',
    icon: 'neurology',
    description:
      'A documentation intelligence agent that indexes product knowledge, generates implementation notes, and keeps engineering context searchable.',
    stack: ['React', 'Node', 'OpenAI'],
    status: 'Live',
    statusTone: 'completed',
  },
  {
    category: 'Platform',
    title: 'DeployGrid',
    icon: 'lan',
    description:
      'Internal deployment dashboard with environment health checks, rollback controls, observability links, and release audit trails.',
    stack: ['Docker', 'AWS', 'Postgres'],
    status: 'In Progress',
    statusTone: 'progress',
  },
  {
    category: 'Full Stack',
    title: 'PulseOps CRM',
    icon: 'monitoring',
    description:
      'Operational CRM for technical teams with pipeline telemetry, client handoff automation, and role-based reporting modules.',
    stack: ['Next.js', 'Prisma', 'Redis'],
    status: 'Completed',
    statusTone: 'completed',
  },
  {
    category: 'Security',
    title: 'VaultBridge',
    icon: 'shield_lock',
    description:
      'Secure credential handoff workflow with access windows, signed activity events, and encrypted project onboarding records.',
    stack: ['TypeScript', 'JWT', 'CI/CD'],
    status: 'Planned',
    statusTone: 'planned',
  },
  {
    category: 'Automation',
    title: 'BuildSentinel',
    icon: 'precision_manufacturing',
    description:
      'Build quality sentinel that tracks failed checks, dependency drift, and production readiness signals from multiple repositories.',
    stack: ['GitHub API', 'Vite', 'Workers'],
    status: 'Live',
    statusTone: 'completed',
  },
];

export const skills = [
  {
    title: 'Frontend Core',
    icon: 'desktop_windows',
    span: 'md:col-span-5',
    items: [
      ['React 19', '95%', '8+ Years'],
      ['Vite & Build Tools', '90%', 'Expert'],
      ['Tailwind CSS', '92%', 'Expert'],
    ],
  },
  {
    title: 'Backend Systems',
    icon: 'dns',
    span: 'md:col-span-7',
    items: [
      ['Node.js APIs', '94%', 'Production'],
      ['Database Design', '88%', 'SQL/NoSQL'],
      ['Auth & Security', '86%', 'Hardened'],
    ],
  },
  {
    title: 'Cloud & DevOps',
    icon: 'cloud_sync',
    span: 'md:col-span-7',
    items: [
      ['AWS Infrastructure', '90%', 'Multi-region'],
      ['Docker / Kubernetes', '84%', 'Reliable'],
      ['CI/CD Pipelines', '93%', 'Automated'],
    ],
  },
  {
    title: 'Engineering Practice',
    icon: 'hub',
    span: 'md:col-span-5',
    items: [
      ['System Architecture', '91%', 'Senior'],
      ['Performance Tuning', '87%', 'Measured'],
      ['Technical Writing', '82%', 'Clear'],
    ],
  },
];

export const credentials = [
  {
    period: '2026 - Present',
    title: 'Matriculation (High School)',
    place: 'Board of Intermediate and Secondary Education, Faisalabad',
    tags: ['Mathematics', 'Computer Science'],
    active: true,
  },
  {
    period: 'Upcoming Pathway',
    title: 'Intermediate ICS',
    place: 'Focusing on Physics, Statistics, and Advanced Computer Programming.',
    tags: ['Physics', 'Statistics', 'Programming'],
  },
  {
    period: 'Planned Track',
    title: 'BS Software Engineering',
    place: 'A long-form academic path focused on distributed systems and applied software architecture.',
    tags: ['Architecture', 'Research', 'Systems'],
  },
];

export const certifications = [
  ['AWS Cloud Practitioner', 'Cloud fundamentals and deployment architecture'],
  ['Meta Front-End Developer', 'Modern React, UI systems, and accessibility'],
  ['Google IT Automation', 'Python automation, Git, and operations workflows'],
];
