import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// All navigation elements and pages imported directly from the components directory
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './components/Home';
import About from './components/About';
import Projects from './components/Projects';
import Skills from './components/Skills';
import Education from './components/Education';
import Contact from './components/Contact';

function App() {
  const [experienceText, setExperienceText] = useState('1 year of experience');

  useEffect(() => {
    // Array of selectable values tracking your experience criteria (3 months to 2 years)
    const values = [
      '3 months', 
      '5 months', 
      '10 months', 
      '1 year', 
      '1.5 years', 
      '2 years'
    ];
    const randomChoice = values[Math.floor(Math.random() * values.length)];
    setExperienceText(`${randomChoice} of experience`);
  }, []);

  return (
    <Router>
      <div className="min-h-screen bg-background text-on-background flex flex-col justify-between overflow-x-hidden selection:bg-primary-container selection:text-white relative">
        <div className="fixed inset-0 z-0 pointer-events-none technical-grid opacity-70" />
        <div className="fixed top-0 left-1/4 w-[500px] h-[500px] bg-primary/10 rounded-full blur-[120px] -translate-y-1/2 pointer-events-none" />
        <div className="fixed bottom-0 right-0 w-[520px] h-[520px] bg-secondary/5 rounded-full blur-[110px] pointer-events-none" />
        <div className="scanline opacity-25" />
        {/* Global Navbar */}
        <Navbar />
        
        {/* Multipage Routing Layout */}
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home exp={experienceText} />} />
            <Route path="/about" element={<About exp={experienceText} />} />
            <Route path="/projects" element={<Projects exp={experienceText} />} />
            <Route path="/skills" element={<Skills exp={experienceText} />} />
            <Route path="/education" element={<Education exp={experienceText} />} />
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </main>
        
        {/* Global Footer */}
        <Footer />
      </div>
    </Router>
  );
}

export default App;
