import { useState } from 'react';
import SectionHeader from './SectionHeader';

const initialState = { name: '', email: '', subject: 'consultation', message: '' };

function Contact() {
  const [form, setForm] = useState(initialState);
  const [status, setStatus] = useState('');

  const updateField = (event) => {
    const { name, value } = event.target;
    setForm((current) => ({ ...current, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!form.name.trim() || !form.email.trim() || !form.message.trim()) {
      setStatus('Please complete the required fields before sending.');
      return;
    }
    setStatus('Transmission queued. I will respond through the supplied return address.');
    setForm(initialState);
  };

  return (
    <main className="relative z-10 pt-32 pb-stack-lg px-margin-mobile md:px-margin-desktop max-w-container-max mx-auto">
      <SectionHeader title="Ready to start a project?">
        I&apos;m currently available for senior engineering roles or high-impact consulting projects. Let&apos;s discuss how
        we can build something robust together.
      </SectionHeader>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-gutter items-start">
        <aside className="lg:col-span-4 flex flex-col gap-gutter order-2 lg:order-1">
          <div className="glass-card p-gutter rounded-xl flex flex-col gap-stack-md">
            <h2 className="font-mono-label text-mono-label uppercase tracking-widest text-primary">System Connect</h2>
            {[
              ['mail', 'Direct Email', 'contact@devcore.tech', 'mailto:contact@devcore.tech'],
              ['terminal', 'Version Control', 'github.com/devcore', '#'],
              ['lan', 'Network', 'linkedin.com/in/devcore', '#'],
            ].map(([icon, label, value, href]) => (
              <a key={label} className="group flex items-center gap-4 p-4 rounded-xl bg-surface-container/50 hover:bg-surface-container transition-all border border-outline-variant/10" href={href}>
                <span className="material-symbols-outlined text-primary">{icon}</span>
                <span>
                  <span className="font-mono-label text-xs uppercase text-on-surface-variant opacity-60 block">{label}</span>
                  <span className="text-on-surface group-hover:text-primary transition-colors">{value}</span>
                </span>
              </a>
            ))}
          </div>
          <div className="relative h-64 rounded-xl overflow-hidden glass-card border border-outline-variant/20">
            <div className="absolute inset-0 technical-grid opacity-70" />
            <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
            <div className="absolute bottom-4 left-4 flex items-center gap-2">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary" />
              </span>
              <span className="font-mono-label text-[10px] uppercase tracking-widest text-on-surface-variant">
                Active: Remote / Faisalabad
              </span>
            </div>
          </div>
        </aside>

        <section className="lg:col-span-8 order-1 lg:order-2">
          <form className="glass-card p-gutter md:p-12 rounded-xl flex flex-col gap-gutter border border-outline-variant/10" onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-gutter">
              <label className="flex flex-col gap-2 font-mono-label text-mono-label uppercase text-on-surface-variant">
                Operator Name
                <input name="name" value={form.name} onChange={updateField} className="form-field" placeholder="John Doe" required type="text" />
              </label>
              <label className="flex flex-col gap-2 font-mono-label text-mono-label uppercase text-on-surface-variant">
                Return Address
                <input name="email" value={form.email} onChange={updateField} className="form-field" placeholder="name@domain.com" required type="email" />
              </label>
            </div>
            <label className="flex flex-col gap-2 font-mono-label text-mono-label uppercase text-on-surface-variant">
              Request Type
              <select name="subject" value={form.subject} onChange={updateField} className="form-field cursor-pointer">
                <option value="consultation">Full-Stack Development Consultation</option>
                <option value="infrastructure">DevOps / Infrastructure Setup</option>
                <option value="partnership">System Architecture Partnership</option>
                <option value="other">General Inquiry</option>
              </select>
            </label>
            <label className="flex flex-col gap-2 font-mono-label text-mono-label uppercase text-on-surface-variant">
              Payload (Message)
              <textarea name="message" value={form.message} onChange={updateField} className="form-field resize-none min-h-40" placeholder="Describe the scope and technical requirements of your project..." required />
            </label>
            <div className="flex flex-col md:flex-row items-center justify-between gap-gutter mt-4">
              <p className="text-xs text-on-surface-variant font-mono-label max-w-xs opacity-70">
                By submitting this request, you agree to secure end-to-end communication via standard protocol.
              </p>
              <button className="w-full md:w-auto bg-primary text-on-primary px-10 py-4 rounded-xl font-bold uppercase tracking-widest hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2" type="submit">
                <span>Execute Send</span>
                <span className="material-symbols-outlined text-[20px]">send</span>
              </button>
            </div>
            {status ? <p className="font-mono-label text-mono-label text-secondary">{status}</p> : null}
          </form>
        </section>
      </div>
    </main>
  );
}

export default Contact;
