function Footer() {
  return (
    <footer className="relative z-10 border-t border-outline-variant/20 py-8">
      <div className="max-w-container-max mx-auto px-margin-mobile md:px-margin-desktop flex flex-col md:flex-row justify-between gap-4 text-on-surface-variant">
        <p className="font-mono-label text-mono-label uppercase tracking-widest">MUNEEB / Obsidian Engineering</p>
        <p className="font-mono-label text-mono-label">Built with React + Tailwind CSS</p>
      </div>
    </footer>
  );
}

export default Footer;
