import SectionHeader from './SectionHeader';

const services = [
  ['full_stack', 'Full-Stack Delivery', 'Production applications with thoughtful UX, robust APIs, and maintainable front-to-back architecture.'],
  ['cloud', 'Infrastructure Design', 'Deployment pipelines, cloud environments, and observability patterns built for reliability under pressure.'],
  ['schema', 'Systems Thinking', 'Clear domain models, resilient data flows, and sharp documentation for teams that need durable decisions.'],
];

function About({ exp }) {
  return (
    <main className="relative z-10 pt-32 pb-stack-lg max-w-container-max mx-auto w-full px-margin-mobile md:px-margin-desktop flex flex-col gap-y-28">
      <section className="pt-16 pb-8 border-l border-white/5 pl-8 md:pl-12 ml-4">
        <h1 className="font-display-lg-mobile md:font-display-lg text-display-lg-mobile md:text-display-lg text-on-surface mb-6 tracking-normal">
          About Me<span className="text-primary">.</span>
        </h1>
        <p className="font-mono-code text-mono-code text-on-surface-variant max-w-2xl border-l-2 border-primary/50 pl-4 py-1">
          &gt; Get to know who I am...
        </p>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-gutter">
        <article className="bg-surface-container-low border border-white/10 rounded-xl p-8 backdrop-blur-sm relative group overflow-hidden hover:bg-surface-container transition-colors">
          <span className="material-symbols-outlined absolute top-4 right-4 text-[64px] opacity-10 group-hover:opacity-20 transition-opacity">
            fingerprint
          </span>
          <h2 className="font-headline-md text-headline-md text-on-surface mb-4 flex items-center gap-3">
            <span className="material-symbols-outlined text-primary text-xl">person</span>
            Who I Am
          </h2>
          <div className="space-y-4 text-on-surface-variant leading-relaxed">
            <p>
              I am a Senior Full-Stack Developer and DevOps Engineer focused on structural integrity, scalable architecture,
              and exacting UI execution.
            </p>
            <p>
              I do not just write code; I design systems that stay understandable after they grow. Current operating window:
              {` ${exp}`}.
            </p>
          </div>
        </article>

        <article className="bg-surface-container-low border border-white/10 rounded-xl p-8 backdrop-blur-sm relative group overflow-hidden hover:bg-surface-container transition-colors">
          <span className="material-symbols-outlined absolute top-4 right-4 text-[64px] opacity-10 group-hover:opacity-20 transition-opacity">
            rocket_launch
          </span>
          <h2 className="font-headline-md text-headline-md text-on-surface mb-4 flex items-center gap-3">
            <span className="material-symbols-outlined text-secondary text-xl">flag</span>
            My Mission
          </h2>
          <div className="space-y-4 text-on-surface-variant leading-relaxed">
            <p>
              To deliver production-ready software that merges user-centered design with uncompromising engineering
              principles.
            </p>
            <p>
              I aim to prove complex enterprise systems can be aesthetically refined, accessible, and highly performant.
            </p>
          </div>
        </article>
      </section>

      <section>
        <SectionHeader eyebrow="What I Do" title="Engineering" highlight="Scope">
          Practical senior engineering across interfaces, services, and deployment systems.
        </SectionHeader>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-gutter">
          {services.map(([icon, title, text]) => (
            <article key={title} className="bg-surface-container-lowest border border-white/5 rounded-lg p-6 group hover:border-primary/30 transition-all">
              <div className="w-12 h-12 rounded bg-surface-container flex items-center justify-center mb-6 group-hover:bg-primary/10 transition-colors">
                <span className="material-symbols-outlined text-primary">{icon}</span>
              </div>
              <h3 className="font-headline-md text-xl text-on-surface mb-3">{title}</h3>
              <p className="text-on-surface-variant leading-relaxed">{text}</p>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}

export default About;
