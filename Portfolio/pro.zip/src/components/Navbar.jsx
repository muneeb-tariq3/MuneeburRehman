import { NavLink } from 'react-router-dom';
import { useState } from 'react';
import { navItems } from '../data/portfolio';

function Navbar() {
  const [open, setOpen] = useState(false);

  const linkClass = ({ isActive }) =>
    `font-mono-label text-mono-label uppercase tracking-widest transition-colors duration-300 ${
      isActive ? 'text-primary font-bold border-b-2 border-primary pb-1' : 'text-on-surface-variant hover:text-primary'
    }`;

  return (
    <>
      <header className="fixed top-0 w-full z-50 bg-surface/80 backdrop-blur-xl border-b border-outline-variant/30">
        <nav className="flex justify-between items-center max-w-container-max mx-auto px-margin-mobile md:px-margin-desktop h-20">
          <NavLink to="/" className="font-headline-md text-2xl md:text-headline-md font-bold text-primary tracking-normal">
            MUNEEB.
          </NavLink>
          <div className="hidden md:flex gap-gutter items-center">
            {navItems.map((item) => (
              <NavLink key={item.path} to={item.path} className={linkClass}>
                {item.label}
              </NavLink>
            ))}
          </div>
          <div className="flex items-center gap-stack-sm">
            <a
              href="/resume.pdf"
              className="hidden md:inline-flex bg-primary text-on-primary px-6 py-2 rounded-lg font-mono-label text-mono-label font-bold active:scale-95 transition-transform"
            >
              Resume
            </a>
            <button
              type="button"
              className="md:hidden text-primary p-2"
              aria-label="Open navigation"
              onClick={() => setOpen(true)}
            >
              <span className="material-symbols-outlined">menu</span>
            </button>
          </div>
        </nav>
      </header>

      <div
        className={`fixed inset-0 z-[60] bg-surface/60 backdrop-blur-sm transition-opacity md:hidden ${
          open ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setOpen(false)}
      />
      <aside
        className={`fixed inset-y-0 right-0 w-80 max-w-[86vw] z-[70] bg-surface-container-high/95 backdrop-blur-2xl border-l border-outline-variant/50 shadow-2xl transition-transform duration-300 md:hidden p-gutter ${
          open ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex justify-between items-center mb-stack-md">
          <div>
            <h2 className="font-headline-md text-headline-md text-primary">Navigation</h2>
            <p className="font-mono-label text-mono-label text-on-surface-variant">Senior Systems Engineer</p>
          </div>
          <button type="button" className="text-on-surface" aria-label="Close navigation" onClick={() => setOpen(false)}>
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>
        <div className="flex flex-col gap-unit">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              onClick={() => setOpen(false)}
              className={({ isActive }) =>
                `flex items-center px-4 py-3 rounded-lg transition-all duration-300 ${
                  isActive
                    ? 'bg-primary-container text-on-primary-container'
                    : 'text-on-surface-variant hover:bg-surface-variant/50 hover:text-on-surface'
                }`
              }
            >
              <span className="material-symbols-outlined mr-4">{item.icon}</span>
              <span className="font-mono-label text-mono-label uppercase tracking-widest">{item.label}</span>
            </NavLink>
          ))}
        </div>
      </aside>
    </>
  );
}

export default Navbar;
